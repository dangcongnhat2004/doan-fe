export const COLORS = {
    primary: "#007AFF", // Màu xanh dương tươi, phù hợp với mobile apps
    primaryDark: "#0051D5", // Màu đậm hơn cho hover/pressed states
    black: "#000000",
    white: "#FFFFFF",
    gray: "#8E8E93",
    lightGray: "#F5F5F5",
    borderGray: "#E5E5E5",
    borderAlert: "#FF3B30", 
    alert: "#FF3B30", 
  };
  