export const Images = {
    logo: require("./logo.png"),
    google: require("./google.png"),
    facebook: require("./facebook.png"),
  };
  